"""
Google Trends 수집기
- pytrends(비공식 라이브러리)로 키워드별 관심도(0~100)를 매일 수집해 CSV에 누적 저장합니다.
- 공식 API가 아니라 비공식 스크래핑 라이브러리이므로, 너무 자주 호출하면
  일시적으로 요청이 막힐 수 있습니다. 하루 1회 실행을 권장합니다.

설치: pip install pytrends pandas
"""

import os
import time
import datetime
import pandas as pd
from pytrends.request import TrendReq

from config import KEYWORDS, TRENDS_GEO, TRENDS_TIMEFRAME, DATA_DIR

OUTPUT_FILE = os.path.join(DATA_DIR, "google_trends_history.csv")


def fetch_trends_batch(keywords_batch, pytrends):
    """Google Trends는 한 번에 최대 5개 키워드만 비교 가능"""
    pytrends.build_payload(keywords_batch, timeframe=TRENDS_TIMEFRAME, geo=TRENDS_GEO)
    df = pytrends.interest_over_time()
    if df.empty:
        return None
    return df


def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    pytrends = TrendReq(hl="en-US", tz=360)

    today = datetime.date.today().isoformat()
    rows = []

    # 5개씩 묶어서 조회 (Google Trends 제약)
    for i in range(0, len(KEYWORDS), 5):
        batch = KEYWORDS[i:i + 5]
        try:
            df = fetch_trends_batch(batch, pytrends)
        except Exception as e:
            print(f"[경고] {batch} 조회 실패: {e}")
            continue

        if df is None:
            continue

        # 최근 7일 평균 관심도를 오늘 날짜 기준 스코어로 저장
        avg_scores = df[batch].mean()
        for kw in batch:
            rows.append({
                "date": today,
                "keyword": kw,
                "trend_score_avg_7d": round(avg_scores[kw], 1),
            })

        time.sleep(2)  # 과도한 호출 방지용 딜레이

    if not rows:
        print("수집된 데이터가 없습니다.")
        return

    new_df = pd.DataFrame(rows)

    if os.path.exists(OUTPUT_FILE):
        old_df = pd.read_csv(OUTPUT_FILE)
        combined = pd.concat([old_df, new_df], ignore_index=True)
        combined.drop_duplicates(subset=["date", "keyword"], keep="last", inplace=True)
    else:
        combined = new_df

    combined.to_csv(OUTPUT_FILE, index=False)
    print(f"저장 완료: {OUTPUT_FILE} ({len(new_df)}개 신규 행)")


if __name__ == "__main__":
    main()
